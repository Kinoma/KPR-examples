/*  Copyright 2011-2016 Marvell Semiconductor, Inc.  Licensed under the Apache License, Version 2.0 (the "License");  you may not use this file except in compliance with the License.  You may obtain a copy of the License at      http://www.apache.org/licenses/LICENSE-2.0  Unless required by applicable law or agreed to in writing, software  distributed under the License is distributed on an "AS IS" BASIS,  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the License for the specific language governing permissions and  limitations under the License.*/
let Pins = require("pins");
let MainSkin = new Skin({ fill: '#F0F0F0',});let ButtonSkin = new Skin({ fill: ['#707070', '#4E4E4E']});let ButtonStyle = new Style({ color: 'white', font: 'bold 50px Helvetica, sans-serif' });
let MainContainer = Container.template($ => ({ 
	left: 0, right: 0, top: 0, bottom: 0, 
	skin: MainSkin, 
	contents: [		Container($, { 
			left: 80, right: 80, top: 80, bottom: 80, 
			active: true, skin: ButtonSkin, state: 0, 
			behavior: Behavior({
				onCreate: function(container) {
					this.ledState = false;
				},
				onTouchBegan: function(container, id, x, y, ticks) {					container.state = 1;
					let currState = this.ledState;			        if ( currState ) {            			Pins.invoke("/light/turnOff");	                               		container.first.string = "turn on";                	} else {            			Pins.invoke("/light/turnOn");	                 		container.first.string = "turn off";                	}                    this.ledState = !currState;				},				onTouchEnded: function(container, id, x, y, ticks) {
					container.state = 0;				},
			}),
			contents: [				Label($, { left: 0, right: 0, top: 0, bottom: 0, style: ButtonStyle, string: 'turn on', }),			]
		}),	]
}));

application.behavior = Behavior({
	onLaunch: function(application) {		Pins.configure({		    light: {		        require: "led",		        pins: {
		        	ground: { pin: 60, type: "Ground" },		            led: { pin: 59 }		        }		    }		}, success => {
			if (success) {        		application.add( new MainContainer() );
			}
		});
	}
});