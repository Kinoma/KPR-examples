/*
  Copyright 2011-2016 Marvell Semiconductor, Inc.  Licensed under the Apache License, Version 2.0 (the "License");  you may not use this file except in compliance with the License.  You may obtain a copy of the License at      http://www.apache.org/licenses/LICENSE-2.0  Unless required by applicable law or agreed to in writing, software  distributed under the License is distributed on an "AS IS" BASIS,  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the License for the specific language governing permissions and  limitations under the License.*/
let Pins = require("pins");let MainSkin = new Skin({ fill: 'white' });let ButtonStyle = new Style({ color: 'black', font: 'bold 50px' });let MainContainer = Container.template($ => ({ 
	left: 0, right: 0, top: 0, bottom: 0, 
	skin: MainSkin, 
	behavior: Behavior({
		clicked: function(container) {			//When button clicked, remove letter from label's string.           	let curString = container.first.string;	        if ( curString.length == 0 ) {            	container.first.string = "Hello World!"            } else {            	container.first.string = curString.substring( 0, curString.length - 1 );           	}		},
	}),
	contents: [		Label($, { left: 0, right: 0, top: 0, bottom: 0, style: ButtonStyle, string: 'Hello World!' }),	]
}));


application.behavior = Behavior({
	onLaunch: function(application) {
		application.add( new MainContainer );
		Pins.configure({			button: {		        require: "button",		        pins: {
		        	power: { pin: 51, type: "Power", voltage: 3.3 },
		        	ground: { pin: 52, type: "Ground" },		            button: { pin: 53},		        }		    }		}, success => {			if (success) {		   		Pins.repeat("/button/wasPressed", 20, result => {					if ( result == true ) application.distribute( "clicked" );		   		});			}		});
	}
});
    