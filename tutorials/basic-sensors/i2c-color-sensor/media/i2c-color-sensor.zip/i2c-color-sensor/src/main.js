/*
  Copyright 2011-2016 Marvell Semiconductor, Inc.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/
let Pins = require("pins");

application.behavior = Behavior({
	onLaunch: function(application) {
		application.skin = new Skin({ fill: 'white' });		Pins.configure({			colorSensor: {				require: "TCS34725",				pins: {					rgb: { sda: 53, clock: 54 },					led: { pin: 51 },
					power: { pin: 55, type: "Power", voltage: 3.3 },
					ground: { pin: 56, type: "Ground" }				}			}		}, success => {
			if (success) {
				Pins.repeat("/colorSensor/getColor", 33, result => {
	                var r = result.r.toString(16), g = result.g.toString(16), b = result.b.toString(16);	                if ( r.length < 2 ) r = "0" + r;	                if ( g.length < 2 ) g = "0" + g;	                if ( b.length < 2 ) b = "0" + b;	                let string = "#" + r + g + b;					application.skin = new Skin(string);
				});
			} else {
				trace("Failed to configure pins.\n");
			}
		});	},
})