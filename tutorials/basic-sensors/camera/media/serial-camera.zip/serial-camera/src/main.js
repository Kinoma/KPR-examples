/*  Copyright 2011-2016 Marvell Semiconductor, Inc.  Licensed under the Apache License, Version 2.0 (the "License");  you may not use this file except in compliance with the License.  You may obtain a copy of the License at      http://www.apache.org/licenses/LICENSE-2.0  Unless required by applicable law or agreed to in writing, software  distributed under the License is distributed on an "AS IS" BASIS,  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the License for the specific language governing permissions and  limitations under the License.*/
let Pins = require("pins");
let flipImage = true; //we put the camera upside down so we should flip the image 180 degrees let flashSkin = new Skin({ fill: 'white' });let defaultSkin = new Skin({ fill: 'green' });let failureSkin = new Skin({ fill: 'red' });let MainContainer = Container.template($ => ({ 
	left: 0, right: 0, top: 0, bottom: 0, 
	behavior: Behavior({
		onHardwareReady: function(container) {			container.skin = defaultSkin;		},		onHardwareFailure: function(container) {			container.skin = failureSkin;			defaultSkin = failureSkin;		},		onButtonTouchBegan: function(container, message, chunk) {			//hide the previous image and display flash 		     	container.image.visible = false;	     	container.skin = flashSkin;		},		onButtonTouchEnded: function(container, message, chunk) {			//ask for a new image to come back (comes as a chunk)s	     	Pins.invoke( "/camera/capture", chunk => {
				//display the image				if ( chunk == false ){				    container.distribute( "onHardwareFailure" );				}				container.image.visible = true;           				container.image.load( chunk );
	     	});	     	container.skin = defaultSkin;		},
	}),
	contents: [		Picture($, { left: 0, right: 0, top: 0, bottom: 0, name: 'image' }),	]
}));application.behavior = Behavior({	onLaunch: function(application) {		let layer = new Layer( { width: 320, height: 240 } );        layer.origin = { x: 160, y: 120 };        let mainContainer = new MainContainer();        layer.add( mainContainer );         if( flipImage ){        	layer.rotation = 180;        } else {            layer.rotation = 0;         }        application.add( layer );                             // Configure the camera and button        Pins.configure({            camera: {                require: "VC0706",                pins: {                    serial: { rx: 33, tx: 31 }                }            },              button: {                require: "Digital",                pins: {
                	power: { pin: 51, type: "Power", voltage: 3.3 },
                	ground: { pin: 52, type: "Ground" },                    digital: { pin: 53, direction: "input" }                }            }        }, success => {
        	 if (success) {
		        //set camera compression to value between 0 and 100 		        Pins.invoke( "/camera/setCompression", 100 );				        //set image size to small		        Pins.invoke( "/camera/setImageSize", { w:320, h:240 } );		        		        //check if button was pressed every 70ms 
		        let prevButtonState = false;
		        Pins.repeat( "/button/read", 70, buttonState => {
		        	if ( !prevButtonState && buttonState ) {						application.distribute( "onButtonTouchBegan" ); 					} else if ( prevButtonState && !buttonState ) {						application.distribute( "onButtonTouchEnded" ); 					}					prevButtonState = buttonState;
		        });
        	}
        }) 	},})